# Documento con immagini

Prima immagine, salvata nella cartella del pacchetto:

![Gradiente blu](images/gradiente.png "Figura 1")

Seconda immagine:

![Quadrato arancione](images/quadrato.png)

Questa immagine remota non viene scaricata (privacy):

![Remota](https://example.org/immagine.png)
